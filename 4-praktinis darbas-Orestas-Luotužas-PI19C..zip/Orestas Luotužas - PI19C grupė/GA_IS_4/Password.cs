﻿namespace GA_IS_4
{
    class Password
    {
        public string Name { get; set; }
        public string _Password { get; set; }
        public string URL { get; set; }
        public string Comment { get; set; }
    }
}
