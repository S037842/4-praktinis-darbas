﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace GA_IS_4
{
    public partial class Auth : Form
    {
        private string cKey = "SUPERRANDOMKEY";

        private static string CSV_PATH = "Auth.csv";

        public Auth()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Slaptažodžio laukas privalo būti užpildytas!");
                return;
            }

            if (string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Vartotojo laukas privalo būti užpildytas!");
                return;
            }

            if (!File.Exists(CSV_PATH))
            {
                List<User> uData = new List<User>();
                uData.Add(new User() { Nick = textBox2.Text, Password = textBox1.Text });

                using (var writer = new StreamWriter(CSV_PATH))
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                    csv.WriteRecords(uData);

                string f = File.ReadAllText(CSV_PATH);
                File.WriteAllText(CSV_PATH, SimpleAES.AES256.Encrypt(f, cKey));
            }
            else
            {
                try
                {
                    string fa = File.ReadAllText(CSV_PATH);
                    File.WriteAllText(CSV_PATH, SimpleAES.AES256.Decrypt(fa, cKey));
                }
                catch
                {

                }

                string cName = "", cPass = "";

                using (var reader = new StreamReader(CSV_PATH))
                using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                {
                    csv.Read();
                    csv.ReadHeader();

                    while (csv.Read())
                    {
                        var record = new User
                        {
                            Nick = csv.GetField("Nick"),
                            Password = csv.GetField("Password"),
                        };

                        cName = record.Nick;
                        cPass = record.Password;
                    }
                }

                string f = File.ReadAllText(CSV_PATH);
                File.WriteAllText(CSV_PATH, SimpleAES.AES256.Encrypt(f, cKey));

                if (textBox1.Text != cPass ||  textBox2.Text != cName)
                {
                    MessageBox.Show("Neteisingas slaptažodis!");
                    return;
                }
            }

            new Main().Show();

            Hide();
        }

        private void Auth_Load(object sender, EventArgs e)
        {
            if (File.Exists("Auth.txt"))
            {
                label1.Text = "Įveskite prisijungimo slaptažodį:";
                button1.Text = "Prisijungti";
            }
        }

        private void Auth_FormClosing(object sender, FormClosingEventArgs e)
        {

        }
    }
}