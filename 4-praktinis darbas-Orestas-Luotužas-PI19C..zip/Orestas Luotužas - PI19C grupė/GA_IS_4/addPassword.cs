﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace GA_IS_4
{
    public partial class addPassword : Form
    {
        Main F;

        private string cKey = "SUPERRANDOMKEY";

        private string CSV_PATH = "Passwords.csv";

        public addPassword(Main M)
        {
            F = M;

            InitializeComponent();
        }

        List<Password> readToList()
        {
            using (var reader = new StreamReader(CSV_PATH))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = new List<Password>();
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    var record = new Password
                    {
                        Name = csv.GetField("Name"),
                        _Password = csv.GetField("_Password"),
                        URL = csv.GetField("URL"),
                        Comment = csv.GetField("Comment")
                    };

                    records.Add(record);
                }
                return records;
            }
        }

        bool containsRecordByName(string _Name)
        {
            bool contains = false;

            using (var reader = new StreamReader(CSV_PATH))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = new List<Password>();
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    var record = new Password { Name = csv.GetField("Name") };

                    if (record.Name == _Name)
                    {
                        contains = true;
                        break;
                    }
                }
            }
            return contains;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (containsRecordByName(textBox1.Text))
                {
                    MessageBox.Show("Įrašas su tokiu pavadinimu jau egzistuoja. Sugalvokite kitokį pavadinimą!");
                    return;
                }

                if (string.IsNullOrEmpty(textBox1.Text))
                {
                    MessageBox.Show("Privalote įvesti pavadinimą!");
                    return;
                }
                if (string.IsNullOrEmpty(textBox2.Text))
                {
                    MessageBox.Show("Privalote įvesti slaptažodį!");
                    return;
                }
                if (string.IsNullOrEmpty(textBox3.Text))
                {
                    MessageBox.Show("Privalote įvesti aplikacijos pavadinimą / URL!");
                    return;
                }

                string encryptedPw = SimpleAES.AES256.Encrypt(textBox1.Text, cKey);

                List<Password> Loaded = readToList();
                Loaded.Add(new Password { Name = textBox1.Text, _Password = encryptedPw, URL = textBox3.Text, Comment = textBox4.Text });


                using (var writer = new StreamWriter(CSV_PATH))
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                    csv.WriteRecords(Loaded);

                F.loadData();

                F.Show();

                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nepavyko pridėti slaptažodžio, bandykite dar kartą!\nKlaida: " + ex.Message);
            }
        }

        private void addPassword_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var stringChars = new char[16];
            var random = new Random();

            for (int i = 0; i < stringChars.Length; i++)
                stringChars[i] = chars[random.Next(chars.Length)];

            var finalString = new String(stringChars);

            textBox2.Text = finalString;
        }

        private void addPassword_FormClosing(object sender, FormClosingEventArgs e)
        {
            F.Show();
        }
    }
}