﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace GA_IS_4
{
    public partial class Main : Form
    {
        private static string CSV_PATH = "Passwords.csv";

        private string cKey = "SUPERRANDOMKEY";

        public Main()
        {
            InitializeComponent();
        }

        private void Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            string pwFile = File.ReadAllText("Passwords.csv");
            string pwFileCrypted = SimpleAES.AES256.Encrypt(pwFile, cKey);
            File.WriteAllText("Passwords.csv", pwFileCrypted);

            Environment.Exit(0);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            addPassword AP = new addPassword(this);
            AP.Show();
            Hide();
        }

        static void writeCSV(List<Password> list)
        {
            using (var writer = new StreamWriter(CSV_PATH))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                csv.WriteRecords(list);
        }

        public void loadData()
        {
            listView1.Items.Clear();

            int id = 1;

            using (var reader = new StreamReader(CSV_PATH))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = new List<Password>();
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    var record = new Password
                    {
                        Name = csv.GetField("Name"),
                        _Password = SimpleAES.AES256.Decrypt(csv.GetField("_Password"), cKey),
                        URL = csv.GetField("URL"),
                        Comment = csv.GetField("Comment")
                    };

                    listView1.Items.Add(new ListViewItem(new string[] { id.ToString(), record.Name, record._Password, record.URL, record.Comment }));

                    id++;
                }
            }
        }

        private void Main_Load(object sender, EventArgs e)
        {
            string pwFile = File.ReadAllText("Passwords.csv");
            string pwFileDeCrypted = SimpleAES.AES256.Decrypt(pwFile, cKey);
            File.WriteAllText("Passwords.csv", pwFileDeCrypted);

            loadData();
        }

        private void toolStripTextBox1_TextChanged(object sender, EventArgs e)
        {
            listView1.Items.Clear();

            int id = 1;

            var records = new List<Password>();

            using (var reader = new StreamReader(CSV_PATH))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    var record = new Password
                    {
                        Name = csv.GetField("Name"),
                        _Password = csv.GetField("_Password"),
                        URL = csv.GetField("URL"),
                        Comment = csv.GetField("Comment")
                    };

                    if (record.Name.Contains(toolStripTextBox1.Text))
                    {
                        listView1.Items.Add(new ListViewItem(new string[] { id.ToString(), record.Name, SimpleAES.AES256.Decrypt(record._Password, cKey), record.URL, record.Comment }));
                        records.Add(record);
                    }

                    id++;
                }
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            int id = 1;

            listView1.Items.Clear();

            var records = new List<Password>();

            using (var reader = new StreamReader(CSV_PATH))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    var record = new Password
                    {
                        Name = csv.GetField("Name"),
                        _Password = csv.GetField("_Password"),
                        URL = csv.GetField("URL"),
                        Comment = csv.GetField("Comment")
                    };

                    if (record.Name == toolStripTextBox2.Text)
                        record.Name = toolStripTextBox3.Text;

                    listView1.Items.Add(new ListViewItem(new string[] { id.ToString(), record.Name, SimpleAES.AES256.Decrypt(record._Password, cKey), record.URL, record.Comment }));

                    records.Add(record);
                    id++;
                }
            }
            writeCSV(records);
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            int id = 1;

            listView1.Items.Clear();

            var records = new List<Password>();

            using (var reader = new StreamReader(CSV_PATH))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    var record = new Password
                    {
                        Name = csv.GetField("Name"),
                        _Password = csv.GetField("_Password"),
                        URL = csv.GetField("URL"),
                        Comment = csv.GetField("Comment")
                    };

                    if (record.Name != toolStripTextBox4.Text)
                    {
                        records.Add(record);

                        string decryptedPw = SimpleAES.AES256.Decrypt(record._Password, cKey);

                        listView1.Items.Add(new ListViewItem(new string[] { id.ToString(), record.Name, decryptedPw, record.URL, record.Comment }));

                        id++;
                    }
                }
            }
            writeCSV(records);
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Clipboard.SetText(listView1.SelectedItems[0].SubItems[1].Text);
        }
    }
}
