﻿namespace GA_IS_4
{
    class User
    {
        public string Nick { get; set; }
        public string Password { get; set; }
    }
}
